import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {Emp} from "./Empdata";

@Injectable({
  providedIn: 'root'
})
export class EmpServService {
public apiUrl:string="http://localhost:3000/emps/";
  constructor(private http:HttpClient) { }
  public E:any;
  getEmps():Observable<Emp[]>
  {
    return this.http.get<Emp[]>(this.apiUrl);
  }
  getEmpById(id:any):Observable<Emp>
  {
     console.log(id);
     this.E=this.http.get<Emp>(this.apiUrl +id);
     console.log(this.E);
     return this.E;
  }
  InsertEmp(Eobj:any)
  {
    return this.http.post<Emp>(this.apiUrl,Eobj);
  }
  UpdateEmp(id:number,Eobj:Emp):Observable<any>
  {
    return this.http.put<any>(this.apiUrl+id,Eobj);
  }
  deleteEmpById(Id:any):Observable<any>
  {
    return this.http.delete<any>(this.apiUrl +Id);
  }
}
