import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { SampleComponent } from './sample/sample.component';
import { Test2Component } from './test2/test2.component';
import { EmpServiceService } from './emp-service.service';
import {HttpClientModule} from '@angular/common/http';
import { EmployeeComponent } from './employee/employee.component';
import { DeptComponent } from './dept/dept.component';
import { FormsComponent } from './forms/forms.component';
import { EmpServService } from './emp-serv.service';
import { ProductsComponent } from './products/products.component';
import { ProductsListComponent } from './products-list/products-list.component';
import { ProductsOverviewComponent } from './products-overview/products-overview.component';
import { DepartmentlistComponent } from './departmentlist/departmentlist.component';
import { OneComponent } from './one/one.component';
import { TwoComponent } from './two/two.component';
import { MatRadioButton } from '@angular/material/radio';
import { MatDateFormats } from '@angular/material/core';
import { SalesComponent } from './sales/sales.component';
import { MarketingComponent } from './marketing/marketing.component';
import { AccountsComponent } from './accounts/accounts.component';
import { Dept1Component } from './dept1/dept1.component';
import { MapComponent } from './map/map.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';
import { EmpbyidComponent } from './empbyid/empbyid.component';
import { FormControlsComponent } from './form-controls/form-controls.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    SampleComponent,
    Test2Component,
    EmployeeComponent,
    DeptComponent,
    FormsComponent,
    
    ProductsComponent,
    ProductsListComponent,
    ProductsOverviewComponent,
    DepartmentlistComponent,
    OneComponent,
    TwoComponent,
    SalesComponent,
    MarketingComponent,
    AccountsComponent,
    Dept1Component,
    MapComponent,
    FeedbackComponent,
    EmpbyidComponent,
    FormControlsComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    
    HttpClientModule,
    BrowserAnimationsModule

  ],
  providers: [EmpServiceService,EmpServService,AuthGuard,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
