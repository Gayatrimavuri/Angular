import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { DeptComponent } from './dept/dept.component';
import { TestComponent } from './test/test.component';
import { FormsComponent } from './forms/forms.component';
import { ProductsComponent } from './products/products.component';
import { ProductsListComponent } from './products-list/products-list.component';
import { ProductsOverviewComponent } from './products-overview/products-overview.component';
import { DepartmentlistComponent } from './departmentlist/departmentlist.component';
import { OneComponent } from './one/one.component';
import { TwoComponent } from './two/two.component';
import { SalesComponent } from './sales/sales.component';
import { MarketingComponent } from './marketing/marketing.component';
import { AccountsComponent } from './accounts/accounts.component';
import { Dept1Component } from './dept1/dept1.component';
import { MapComponent } from './map/map.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AuthGuard } from './auth.guard';
import { ChildguardGuard } from './childguard.guard';
import { CanloadGuard } from './canload.guard';
import { EmpbyidComponent } from './empbyid/empbyid.component';

  import { FormControlsComponent } from './form-controls/form-controls.component';
import { CandeactivateGuard } from './candeactivate.guard';
import { AddressComponent } from './address/address.component';
import { DashboardComponent } from './dashboard/dashboard.component';
const routes: Routes = [
  {path:'dlist1',redirectTo:'/dlist',pathMatch:'full'},
{path:"emp",component:EmployeeComponent},
{path:"dept",component:DeptComponent},
{path:"formcontrol",component:FormControlsComponent,canActivate:[AuthGuard],canDeactivate:[CandeactivateGuard]},
{path:'address',component:AddressComponent},
{path:"test",component:TestComponent},
{path:"form",component:FormsComponent},
{path:"empbyid/:id",component:EmpbyidComponent},
{path:"dashboard",component:DashboardComponent},



{path:"sales",component:SalesComponent,children:
[
  {path:'map',component:MapComponent,outlet:'maproute'},
  {path:'feedback',component:FeedbackComponent,outlet:'feedbackroute'},
]},
{path:"mktg",component:MarketingComponent},

{path:"acccounts",component:AccountsComponent},
{path:"products",children:
[
  {path:"list",component:ProductsListComponent},
  {path:"Overview",component:ProductsOverviewComponent}
  

],component:ProductsComponent},
{path:"dlist",component:DepartmentlistComponent},
{path:"dept1/:id",component:Dept1Component},
  { path: 'customers', loadChildren: () => import('./customers/customers.module').then(m => m.CustomersModule) ,
  canLoad:[CanloadGuard]},
 
 
 { path: 'Admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),canLoad:[CanloadGuard] },
  


];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[DeptComponent,EmployeeComponent,ProductsComponent,ProductsListComponent,ProductsOverviewComponent];