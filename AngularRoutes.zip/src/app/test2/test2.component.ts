import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';
@Component({
  selector: 'app-test2',
  template: `
  <input #myInput type="text">
  <button (click)="onClicking(myInput.value)">Hello</button>
  {{message}}  
  <input #myInput2 type="text">
  <button (click)="msg='Welcome' +myInput2.value">Hello</button>
  {{msg}}
  <input #myInput3 type="text" (blur)="msg2='Welcome'+myInput3.value">
  {{msg2}}
  <input #myInput4 type="text">
  <button (click)="onClicking1(myInput4)">Hello</button>
  {{msg3}}  
  {{msg4}}
  <input type="text" [(ngModel)]="empname">
  {{empname}}
  <button (click)="display()" >TwoWay</button>

  <div *ngIf="false; else ebl">
    <input type="text" value="If Block" >
  </div>
  <ng-template #ebl>
  <input type="text" value="Else Block" >
  
  </ng-template>
  <div *ngIf="displayctrl;else eblock">
  Techwave
</div>
<ng-template #eblock>
  No Data
</ng-template>
<div *ngIf="displayctrl;then thenblock;else elseblock"></div>
<ng-template #thenblock>
  Techwave New
</ng-template>
<ng-template #elseblock>
  No Data New
</ng-template>

<ng-template [ngIf]="marks>90" [ngIfElse]="elseblock1">
      <div> Excellent</div>
</ng-template>
<ng-template #elseblock1 >
      <ng-template [ngIf]="marks>80" [ngIfElse]="elseblock2">
            <div>Very Good</div>
      </ng-template>
</ng-template>
<ng-template #elseblock2 >
      <ng-template [ngIf]="marks>70" [ngIfElse]="elseblock3">
          <div>Good</div>
      </ng-template>
</ng-template>
<ng-template #elseblock3>
      <div>Must improve</div>
</ng-template>

<div *ngFor="let c of colors">
<h1 [style.color]="c" >{{c}}</h1>
</div>
{{parentdata}}
<button (click)="fireEvent()">Button1</button>
<button (click)="fireEvent2()">Button2</button>
<ul *ngFor="let e of this.Elist" type='a'>
  <li>{{e.Name + " " + e.Id+ " " +e.Age}}</li>
</ul>


`,
  styleUrls: ['./test2.component.css']
})
export class Test2Component implements OnInit {
 public Elist:any=[];
  constructor(private ES:EmpServiceService) { }
  @Input() public parentdata:any;
  @Output() public childEnt=new EventEmitter();

  public colors=["red","green","blue","yellow"];
  public color='green';
  public marks=55;
  public message="";
  public msg="";
  public msg2="";
  public msg3="";
 public msg4="hello";
 public displayctrl=true;
 public empname="Vamshi Krishna"; 
  ngOnInit(): void {
  //  this.Elist=this.ES.getEmps();
 this.Elist= this.ES.getEmps().subscribe(data=>this.Elist=data);
  }
  
  onClicking(value:any)
  {
    
    this.message=value;
     console.log();
  }
  onClicking1(myInput4:any)
  {
    this.msg3=myInput4.value;
     console.log();
  }
  display()
  {
    console.log(this.empname);
  }
  fireEvent()
  {
    this.childEnt.emit('String from Child to Parent');
  }
  fireEvent2()
  {
    this.childEnt.emit('String from Child to Parent Second time');
  }

}
