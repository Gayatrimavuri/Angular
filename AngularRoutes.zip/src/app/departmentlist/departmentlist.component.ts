import { identifierName } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-departmentlist',
  templateUrl: './departmentlist.component.html',
  styleUrls: ['./departmentlist.component.css']
})
export class DepartmentlistComponent implements OnInit {

  constructor(private router:Router,private route:ActivatedRoute) { }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  public departments=
  [
    {"id":1,"name":"Sales"},
    {"id":2,"name":"Marketing"},
    {"id":3,"name":"Accounts"},
    {"id":4,"name":"Finance"}
    

  ];
  public selectedId:any;

  
  onSelect(department:any)
  {
    alert(department);
    //if(department==1)

    this.router.navigate(['dept1',department]);        
  }
  
}
