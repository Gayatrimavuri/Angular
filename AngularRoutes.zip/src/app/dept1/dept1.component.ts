import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-dept1',
  templateUrl: './dept1.component.html',
  styleUrls: ['./dept1.component.css']
})
export class Dept1Component implements OnInit {

  constructor(private route:ActivatedRoute) { }

  ngOnInit(): void {
    console.log(this.route.snapshot.params['id']);

      
  }

}
