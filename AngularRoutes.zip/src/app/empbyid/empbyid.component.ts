import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmpServService } from '../emp-serv.service';
import { Emp } from '../Empdata';

@Component({
  selector: 'app-empbyid',
  templateUrl: './empbyid.component.html',
  styleUrls: ['./empbyid.component.css']
})
export class EmpbyidComponent implements OnInit {

  constructor(private service:EmpServService,private route:ActivatedRoute) { }
  public emp=new Emp();

  ngOnInit(): void {
    console.log(this.route);
    let id=this.route.snapshot.params['id'];
    console.log(id);
    this.service.getEmpById(id).subscribe(data=>{this.emp=data;});
    console.log(this.emp.id);
  }

}
