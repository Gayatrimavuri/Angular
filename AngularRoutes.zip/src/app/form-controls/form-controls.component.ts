import { Component, OnInit } from '@angular/core';
import { EmpServService } from '../emp-serv.service';
import { Emp } from '../Empdata';

@Component({
  selector: 'app-form-controls',
  templateUrl: './form-controls.component.html',
  styleUrls: ['./form-controls.component.css']
})
export class FormControlsComponent implements OnInit {

  public types=['Permanent','Contract'];
  public empModel=new Emp();
  public hasTypeError=false;
 public isDirty=true;
  constructor(private eservice:EmpServService) { }
  public Earray:any=[];
  ngOnInit(): void {
    this.getEmployees();
  
  }
 
  getEmployees()
  {
   
    this.eservice.getEmps().subscribe((result:any)=>{
      console.log(result);
      this.Earray=result;
    });
  }
  onsubmit(empForm:any)
  {
    this.isDirty=false;

    this.eservice.InsertEmp(this.empModel).subscribe((result:any)=>{
      alert ("1 Emp added");
      this.getEmployees(); 
      console.log(empForm.form.isDirty);
      window.location.reload();
  
    })
    console.log(this.empModel.id+" "+empForm.Name+" "+empForm.Age+" "+empForm.Gender+" "+empForm.Type);
  }
  validatetype(value:any)
  {
    if(value=="-1")
        this.hasTypeError=true;
    else
        this.hasTypeError=false;
  }
}
