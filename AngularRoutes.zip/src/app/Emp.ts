export interface IEmp
{
    Id:number;
    Name:string;
    Age:number;
}