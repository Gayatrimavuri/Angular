import { Component, OnInit } from '@angular/core';
import { Emp } from '../Empdata';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {
public type=['Permanent','Contract'];
  constructor() { }
  empmodel=new Emp();

  ngOnInit(): void {
  }
  onSubmit()
  {
    console.log(this.empmodel.id+ " "+ this.empmodel.Name+ " "+this.empmodel.Age+" "+this.empmodel.Type);
  }
}
