import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public isLoggedin:boolean;
  public isAdmin:boolean;
  
  constructor() 
  {
    this.isLoggedin=true;
    this.isAdmin=true;
   }
  CheckLogin()
  {
    return this.isLoggedin;
  }
  CheckAdmin()
  {
    return this.isAdmin;
  }
}
