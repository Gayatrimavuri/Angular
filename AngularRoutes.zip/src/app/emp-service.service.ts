import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IEmp } from './Emp';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {
 public _url:string="http://localhost:3000/emps";
  constructor(private http:HttpClient){}
  public emps=[
    {"Id":1,"Name":"Monika","Age":21},
    {"Id":2,"Name":"Vamshi","Age":21},
    {"Id":3,"Name":"Praveen","Age":21},
    {"Id":4,"Name":"Pavan","Age":21},
    {"Id":5,"Name":"Neha","Age":21}
  ];
  getEmps():Observable<IEmp[]>
  {
    return this.http.get<IEmp[]>(this._url);
    
  }
  public apiUrl:string="http://localhost:3000/emps/";
 
  getContacts():Observable<IEmp>
  {
    return this.http.get<IEmp>(this.apiUrl);
  }
  deleteContactByName(value:any):Observable<any>
  {
    return this.http.delete<any>(this.apiUrl+value);
  }
  postContact(data:any):Observable<IEmp>
  {
    return this.http.post<IEmp>(this.apiUrl,data)
  }
  updateContact(id:number,value:any):Observable<any>
  {
    return this.http.put<any>(this.apiUrl+id,value);
  }
}
