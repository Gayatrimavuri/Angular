import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addusers',
  templateUrl: './addusers.component.html',
  styleUrls: ['./addusers.component.css']
})
export class AddusersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
