import { Component, OnInit } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
public Elist:any=[];
  constructor(private ES:EmpServiceService) { }

  ngOnInit(): void {
    //  this.Elist=this.ES.getEmps();
         this.Elist= this.ES.getEmps().subscribe(data=>this.Elist=data);
    }
   
}
