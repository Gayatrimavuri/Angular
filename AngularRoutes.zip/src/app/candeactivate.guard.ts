import { Component, Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { FormControlsComponent } from './form-controls/form-controls.component';

@Injectable({
  providedIn: 'root'
})
export class CandeactivateGuard implements CanActivate, CanDeactivate<FormControlsComponent> {
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return true;
  }
  canDeactivate(
    component: FormControlsComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): boolean {
      if(component.isDirty)
      {
        return window.confirm("Sure");
      }
    return true;
  }
  
}
