import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-sample',
  template: `
  <button (click)="onClick1($event)">Greet</button>
  <button (click)="greeting2='Welcome to techwave'">Greet</button>
  {{greeting}}
  {{greeting1}}
  {{greeting2}}
  {{name}}
  <input #myInput type="text">
  <button (click)="logMessage(myInput.value)">Log</button>
{{name1}}
<button (click)="fireEvent()"></button>
  `,  
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {

  constructor() { }
  public greeting="";public greeting1="";
  public greeting2="";
  public name="";
  @Input('parentdata') public name1:any;
  @Output() public childEvent=new EventEmitter();
  ngOnInit(): void {
  }
onClick1(event:any)
{
  this.greeting='welcome to Angular';
  this.greeting1=event.type;
  
  console.log(event)

}
fireEvent()
{
  this.childEvent.emit("Gayatri Arisam");
}
logMessage(value:any)
{
this.name=value;
}
}
