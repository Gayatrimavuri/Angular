import { Component, OnInit } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';

@Component({
  selector: 'app-test',
  template: `<h1>Hello all</h1>
             <h2>Hello {{name}} </h2>
             <h2>{{2+4}}</h2>
             <h2>{{name.length}}</h2>
             <h2>{{name.toUpperCase()}}</h2>
             <h2>{{helloUser()}}</h2>
            <h2>{{url}}</h2>
            <input type="text" value="techwave" id="test">
            <input type="text" value="techwave" id="test1" [disabled]="isdisabled">
            <h2 [class]="Mystyle"> Hi Tech City with class</h2> 
            
            <h2 [class]=ChangeStyle() class="text-special"> Hi Tech City</h2> 
            <h2 [class]="Mystyle" class="text-special"> Hi Tech City</h2> 
            <h2 [class.text-danger]="hasError" class="text-success"> Hi Tech City</h2> 
            <h2 [class.text-danger]=checkMarks() class="text-success"> Marks Result</h2> 
            <h2 [class]="Mystyle">{{getResults()}}</h2> 
            <h1>{{result}}</h1>
            <h1 style="color:red;">This is Style binding</h1>
            <h1 [style.color]="col">This is Style binding</h1>
            <h1 [style.color]="iserror?'red':'green'">This is Style binding</h1>
            <h1 [ngStyle]="title">This is for multiple styles</h1>     
            <ul *ngFor="let e of this.Elist" type='a'>
            <li>{{e.Name + " " + e.Id+ " " +e.Age}}</li>
          </ul>
          
            `,
  styles: [`
   .text-success
   {
    color:green;
   }
   .text-moderate
   {
    color:yellow;
   }
   .text-danger
   {
    color:red;
   }
  .text-special
  {
    font-style:italic;
  }
  `]
})
export class TestComponent implements OnInit {
  public Elist:any=[];

  constructor(private ES:EmpServiceService) { }
  public  name="techwave Consultancy";
  public url=window.location.href;
  public myId="testId";
  public marks=96;
  public isdisabled=false;
  public Mystyle="";
  public hasError=false;
  public result="";
  public col='green';
  public iserror=true;
  public title={
    color:"pink",
    fontStyle:"italic"
  }
  ngOnInit(): void {
    this.Elist=this.ES.emps;
  }
  helloUser()
  {
    return "Welcome "+ this.name;
  }
  checkMarks():boolean
  {
    if(this.marks>=90)
      return false;
      else
      return true;

  }
  ChangeStyle()
  {
    if(this.marks>=90)
    return "text-success";
    else
    return "text-danger"; 
  }
  getResults()
  {
    if(this.marks>=90)
    {
    this.Mystyle="text-success";
    this.result="Excellent";
    return "Excellent";
    }
    else if(this.marks>=70)
    {
      this.Mystyle="text-moderate";
      this.result="Good";
      return "Good";
  
    }
    else
    {
      this.Mystyle="text-danger";
      this.result="Must Improve";
      return "Must Improve";
    
    }

  }

}
