import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ChildguardGuard implements CanActivateChild {
  constructor(private auth:AuthService){}
  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean{
    if(this.auth.CheckAdmin())
    {
      return true;
    }
    else{
      alert('you are not allowed');
      return false;
    }
  }
  
}
