export class Emp
{
    public id:number;
    public Name:string;
    public Age:number;
    public Gender:string;
    public Type:string;
    public Pancard:string;
   
    constructor(){}

    // constructor(
    //     )
    // {}
}
