import {NgModule} from "@angular/core";
import {Routes,RouterModule} from "@angular/router";
import {ProjectListComponent} from './project-list/project-list.component'
import {CreateProjectComponent} from "./create-project/create-project.component";
import {UpdateProjectComponent} from "./update-project/update-project.component";
import {ProjectDetailsComponent} from "./project-details/project-details.component";
import { LoginComponent } from "./login/login.component";
import { AdminComponent } from "./admin/admin.component";
const routes:Routes=
  [
    {path:'projects',component:ProjectListComponent},
    {path:'create-project',component:CreateProjectComponent},
    {path:'Login',component:LoginComponent},
    {path:'admin',component:AdminComponent},

    {path:'update-project/:projectId',component:UpdateProjectComponent},
    {path:'project-details/:projectId',component:ProjectDetailsComponent}

  ];
@NgModule({
  imports:[RouterModule.forRoot(routes)],
  exports:[RouterModule]

})
export class ApRoutingModule{}
