import { TestBed } from '@angular/core/testing';

import { SettingscheckGuard } from './settingscheck.guard';

describe('SettingscheckGuard', () => {
  let guard: SettingscheckGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(SettingscheckGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
