import { Component, OnInit } from '@angular/core';
import {Project} from "../project";
import {ProjectService} from "../project.service";
import {ActivatedRoute,Router} from "@angular/router";

@Component({
  selector: 'app-update-project',
  templateUrl: './update-project.component.html',
  styleUrls: ['./update-project.component.css']
})
export class UpdateProjectComponent implements OnInit {

  projectId:number;
  project:Project=new Project();
  constructor(private projectService:ProjectService,private route:ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    this.projectId=this.route.snapshot.params['projectId'];
    this.projectService.getProject(this.projectId).subscribe(data=>{this.project=data;});
  }
onSubmit()
{
  this.projectService.updateProject(this.projectId,this.project).subscribe(data=>{console.log(data);this.gotoProjectList();})
}
gotoProjectList()
  {
    this.router.navigate(['/projects']);
  }
}
