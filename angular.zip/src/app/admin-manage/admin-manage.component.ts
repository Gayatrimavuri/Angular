import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-manage',
  templateUrl: './admin-manage.component.html',
  styleUrls: ['./admin-manage.component.css']
})
export class AdminManageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
