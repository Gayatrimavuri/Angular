import { Component, OnInit } from '@angular/core';
import {Project} from "../project";
import {ActivatedRoute} from "@angular/router";
import {ProjectService} from "../project.service";

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit {

  projectId:number;
  project:Project;
  constructor(private route:ActivatedRoute,private projectService:ProjectService) { }

  ngOnInit(): void {
  this.projectId=this.route.snapshot.params['projectId'];
  this.project=new Project();
  this.projectService.getProject(this.projectId).subscribe(data=>{this.project=data});
  }

}
