export class Project{
  projectId:number;
  projectDesc:string;
  startDate:Date;
  projectHead:string;

}
