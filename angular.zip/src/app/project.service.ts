import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Project} from "./project";

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
private baseURL="http://localhost:9000/api/v1/Project";
constructor(private httpClient:HttpClient){}
  getProjects():Observable<Project[]>
  {
    return this.httpClient.get<Project[]>(`${this.baseURL}`);
  }
  addProject(project:Project):Observable<Object>
  {
    return this.httpClient.post(`${this.baseURL}`,project);
  }
  getProject(projectId:number):Observable<Project>
  {
    return this.httpClient.get<Project>(`${this.baseURL}/${projectId}`);

  }
  updateProject(projectId:number,project: Project):Observable<Object>
  {
    return this.httpClient.put<Project>(`${this.baseURL}/${projectId}`,project);

  }
  deleteProject(projectId:number):Observable<Object>
  {
    return this.httpClient.delete<Project>(`${this.baseURL}/${projectId}`);
  }
}

