import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ProjectListComponent} from "./project-list/project-list.component";
import {CreateProjectComponent} from "./create-project/create-project.component";
import {UpdateProjectComponent} from "./update-project/update-project.component";
import {ProjectDetailsComponent} from "./project-details/project-details.component";
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { SuperadminGuard } from './superadmin.guard';
import { AdminComponent } from './admin/admin.component';
import { AdminManageComponent } from './admin-manage/admin-manage.component';
import { AdminEditComponent } from './admin-edit/admin-edit.component';
import { AdminDeleteComponent } from './admin-delete/admin-delete.component';
import { AdminaccessGuard } from './adminaccess.guard';
import { SettingscheckGuard } from './settingscheck.guard';
import { UnsavedGuard } from './unsaved.guard';

const routes: Routes = [
  {path:"projects",component:ProjectListComponent,canDeactivate:[UnsavedGuard]},
  {path:"create-project",component:CreateProjectComponent,canActivate:[AuthGuard]},
  {path:'',redirectTo:'projects',pathMatch:'full'},
  {path:"update-project/:projectId",component:UpdateProjectComponent},
  {path:"project-details/:projectId",component:ProjectDetailsComponent},
  {path:"login", component:LoginComponent},
  {path:"admin",
  canActivate:[SuperadminGuard],
  children:[
    {
    path:'',
    component:AdminComponent,
    },
    {
     path:'',
     canActivateChild:[AdminaccessGuard],
children:[
    {path:'manage',component:AdminManageComponent},
    {path:'edit',component:AdminEditComponent},
    {path:'delete',component:AdminDeleteComponent}
    ]}
  ]
  },
  { path: 'settings',
  canLoad:[SettingscheckGuard],
  loadChildren: () => import('./settings/settings.module').then(m => m.SettingsModule) }];







@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
